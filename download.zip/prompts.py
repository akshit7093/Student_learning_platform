# prompts.py
from langchain.prompts import PromptTemplate
from langchain_core.pydantic_v1 import BaseModel, Field
from typing import List

# --- Pydantic Models for Structured Report Output ---

class ScoreMetric(BaseModel):
    parameter: str = Field(description="The name of the parameter being scored, e.g., 'Problem Volume'.")
    score: int = Field(description="The student's score on a scale of 1-10.")
    justification: str = Field(description="A brief, data-driven justification for the assigned score.")

class StrengthWeakness(BaseModel):
    strengths: List[str] = Field(description="A list of the student's key strengths, citing specific data points.")
    weaknesses: List[str] = Field(description="A list of areas for improvement, citing specific data points.")

class Recommendation(BaseModel):
    recommendations: List[str] = Field(description="A list of 2-3 actionable, personalized recommendations for the student.")

class StudentReport(BaseModel):
    """The complete structured report for a student."""
    overall_summary: str = Field(description="A one-paragraph 'HR Summary' of the student's overall profile.")
    detailed_scores: List[ScoreMetric] = Field(description="A list of scores for each parameter.")
    analysis: StrengthWeakness = Field(description="An analysis of strengths and weaknesses.")
    actionable_advice: Recommendation = Field(description="Personalized advice for improvement.")


# --- Prompt Templates ---

# Prompt for the structured, detailed report
REPORT_PROMPT_TEMPLATE = """
You are an expert AI career coach and technical recruiter. Your task is to generate a comprehensive, data-driven performance report for a student based on the provided context.

**Student Profile Context:**
{context}

**Instructions:**
Analyze the context thoroughly and generate a report based *only* on the provided data. Adhere strictly to the scoring rubric and the JSON output format.

**Scoring Rubric:**
1.  **Problem Volume (20%):** Score based on the total number of problems solved on platforms like LeetCode and Codeforces.
2.  **Problem Distribution (25%):** Score based on the ratio of Easy, Medium, and Hard problems on LeetCode and the rating of problems on Codeforces. Higher scores for tackling more difficult problems.
3.  **Acceptance Rate (10%):** Score based on the LeetCode acceptance rate. Higher is better.
4.  **Consistency and Activity (10%):** Score based on LeetCode streaks, active days, and GitHub contribution frequency (last pushed dates).
5.  **Topic Coverage/Depth (25%):** Score based on the breadth and depth of topics covered in LeetCode/Codeforces (top skills, tags) and the diversity of projects on GitHub.
6.  **Programming Language Skill (5%):** Score based on the primary language used and the variety of languages in projects.
7.  **Recent Activity (5%):** Score based on recent submissions and commits. More recent activity is better.

**Output Format:**
You MUST provide your response in the JSON format specified below. Do not add any text before or after the JSON object.

**JSON Schema:**
{format_instructions}
"""

# Prompt for the conversational chatbot
QA_PROMPT_TEMPLATE = """
You are a helpful AI assistant for analyzing a student's profile. Answer the following question based *only* on the provided context.
If the context does not contain the answer, state that the information is not available in the student's profile. Do not make up information.

**Context:**
{context}

**Question:**
{question}

**Answer:**
"""

REPORT_PROMPT = PromptTemplate(
    template=REPORT_PROMPT_TEMPLATE,
    input_variables=["context"],
    partial_variables={"format_instructions": StudentReport.schema_json()}
)

QA_PROMPT = PromptTemplate(
    template=QA_PROMPT_TEMPLATE,
    input_variables=["context", "question"]
)