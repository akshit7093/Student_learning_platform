# main.py
from rag_system import StudentDirectApiRAG # <-- CHANGED IMPORT
import json
import os

def display_help():
    print("\n--- Student Analyzer Chatbot (Direct API) ---")
    print("Commands:")
    print("  select <enrollment_no>   - Select a student profile to analyze.")
    print("  report                   - Generate a full, structured performance report.")
    print("  ask <your_question>      - Ask a specific question about the student.")
    print("  whoami                   - Show the currently selected student.")
    print("  help                     - Show this help message.")
    print("  exit                     - Exit the application.")
    print("---------------------------------------------")

def main():
    # Ensure the API key is set
    if "GOOGLE_API_KEY" not in os.environ:
        print("ERROR: Please set the GOOGLE_API_KEY environment variable.")
        return

    try:
        rag_system = StudentDirectApiRAG() # <-- CHANGED CLASS NAME
    except Exception as e:
        print(f"Fatal error during initialization: {e}")
        return
        
    current_student = None
    student_name = ""

    display_help()

    while True:
        prompt = f"({student_name}) > " if current_student else "> "
        user_input = input(prompt).strip()

        if user_input.lower() == 'exit':
            break
        elif user_input.lower() == 'help':
            display_help()
            continue
        elif user_input.lower() == 'whoami':
            if current_student:
                print(f"Currently analyzing: {student_name} ({current_student})")
            else:
                print("No student selected. Use 'select <enrollment_no>'.")
            continue

        if user_input.lower().startswith('select '):
            parts = user_input.split()
            if len(parts) == 2:
                enrollment_no_to_select = parts[1]
                student_profile = rag_system.student_data.get(enrollment_no_to_select)
                if student_profile:
                    current_student = enrollment_no_to_select
                    student_name = student_profile.get("name", "Unknown")
                    print(f"Selected student: {student_name} ({current_student})")
                else:
                    print(f"Error: Could not find student with enrollment no '{enrollment_no_to_select}'.")
            else:
                print("Invalid command. Usage: select <enrollment_no>")
            continue

        if not current_student:
            print("Please select a student first using 'select <enrollment_no>'.")
            continue

        if user_input.lower() == 'report':
            print("\n--- Generating Full Performance Report (this may take a moment)... ---")
            report = rag_system.generate_structured_report(current_student)
            print(json.dumps(report, indent=2))
            print("---------------------------------------------------------------------\n")
        
        elif user_input.lower().startswith('ask '):
            question = user_input[4:].strip()
            if question:
                print("\nThinking...")
                answer = rag_system.answer_question(question, current_student)
                print(f"AI: {answer}\n")
            else:
                print("Please provide a question after 'ask'.")
        else:
            print("Invalid command. Type 'help' to see the available commands.")

if __name__ == "__main__":
    main()